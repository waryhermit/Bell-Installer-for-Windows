$(document).ready(function() {
	$('input[name="submitButton"]').removeAttr('disabled');
	// reset select source couch server dropdown
	$("#selectCouchSource").val("");
	// reset textbox holding selected source couch server's address
	$("#txtboxCouchServerSrc").val("");
});

var socket = io.connect();
function addMessage(msg) {
	$("#socketRespFromServer").html('<div class="message">' + msg + '</div>');
}

socket.on('statusOnStarterDataPrep', function(statusMsg) {
	if (statusMsg.err) {
		alert("Failed to prepare data out of chosen items. Plz try again");
	} else {
		// enable button and show status of starter-data-prep task
		alert("Successfully prepared data out of chosen items. You can pick data from location: " + "'D:\\StarterDataLocation'");
		$('input[name="submitButton"]').removeAttr('disabled');
		// addMessage(statusMsg.msg);
	}
});	

socket.on('resourcesDataForSelectedPage', function(resourcesForThePage) {
	if (resourcesForThePage.err) {
		alert("Failed to fetch records for the selected page. Plz try again");
	} else {
		showTheseResourcesOnTheSelectResourcesPanel(resourcesForThePage);		
	}
});

function showTheseCoursesOnTheSelectCoursesPanel(coursesFetched) {
	$("#selectCourses").html('');
	$("#selectCourses").append("<h3>Choose Courses</h3>");	
	for(var i = 0; i < coursesFetched.length; i++) { 
    	var courseInfo = coursesFetched[i];
    	var checkbox = document.createElement('input');
		checkbox.type = "checkbox";
		checkbox.name = "cbCourses";
		checkbox.id = "cbCourses";
		checkbox.value = courseInfo.id;
		var label = document.createElement('label');
		label.htmlFor = "cbCourses";
		label.appendChild(document.createTextNode(courseInfo.name));
		var br = document.createElement('br');
		$("#selectCourses").append(checkbox); $("#selectCourses").append(label); $("#selectCourses").append(br);		
 	}
}

function showTheseResourcesOnTheSelectResourcesPanel(resourcesFetched) {
	$("#selectResources").html('');
	$("#selectResources").append("<h3>Choose Resources</h3>");
	for(var i = 0; i < resourcesFetched.length; i++) { 
    	var resourceInfo = resourcesFetched[i];
    	var checkbox = document.createElement('input');
		checkbox.type = "checkbox";
		checkbox.name = "cbResources";
		checkbox.id = "cbResources";
		checkbox.value = resourceInfo.id;
		var label = document.createElement('label');
		label.htmlFor = "cbResources";
		label.appendChild(document.createTextNode(resourceInfo.name));
		var br = document.createElement('br');
		$("#selectResources").append(checkbox); $("#selectResources").append(label); $("#selectResources").append(br);		
 	}
}

socket.on('dataFromChosenBeLLCouch', function(data) {
	if(data.err !== null) {
		alert("Failed to access data from the BeLL you identified. Plz recheck the address and try again");
	} else {
		// remove submit button so that it does not get added twice
		$("#submitButton").remove();
		// append courses to courses panel/div #selectCourses
		showTheseCoursesOnTheSelectCoursesPanel(data.arrCourses);
	 	// append resources to resources panel/div #selectCourses
	 	showTheseResourcesOnTheSelectResourcesPanel(data.arrResources);
	 	// if allResourcesCount > resourcesFetched.length, then add another div for pagination	 	
	 	if (data.resourcesCount > data.arrResources.length) {
	 		// alert("heeyyy");
	 		var itemsPerPage = data.arrResources.length;
	 		var pagesCount = Math.ceil(data.resourcesCount/itemsPerPage);
	 		console.log("ceil input: " + (data.resourcesCount/itemsPerPage));
	 		$("#paginator").paginate({
	 			count 					: pagesCount,
				start 					: 1,
				display     			: 7,
				border					: true,
				border_color			: '#fff',
				text_color  			: '#fff',
				background_color    	: 'black',	
				border_hover_color		: '#ccc',
				text_hover_color  		: '#000',
				background_hover_color	: '#fff', 
				images					: false,
				mouse					: 'press',
				onChange: function (page) {
					socket.emit('fetchResourcesForIthPage', page);
				}
			});
	 	}
	 	// append the form submit equivalent button (not exactly a form submit button but just a button to act like that)
	 	var button = document.createElement("input");
	    button.type = "button";
	    button.value = "Prepare Starter Data"; 
	    button.name = "submitButton"; 
	    button.id = "submitButton";  
	    button.onclick = function() { // Note this is a function
	        prepareStarterData(this);
	    };
	    $("#dataSelectionPanel").append(button); 
	}
});	

function prepareStarterData(event) {
	// make the button disabled and reset the status of starter data prep task and preferably show a spinner too
	$('input[name="submitButton"]').attr('disabled','disabled');
	$("#socketRespFromServer").html('');
	var ids = [], resourceIds = [];
	$('#selectCourses input:checked').each(function() {
	    ids.push($(this).val());
	});
	$('#selectResources input:checked').each(function() {
	    resourceIds.push($(this).val());
	});
	if ( (ids.length === 0) && (resourceIds.length === 0) ) {
		alert("You did not choose any items");
	} else {		
		var selectedCoursesAndResources = {courseIds: ids, resourceIds: resourceIds};
		socket.emit('includeCoursesInStarterData', selectedCoursesAndResources);
	}
}

function testing(event) {
	var data;
	socket.emit('testing', data);
}

function viewDataFromSelBeLL(event) { // button's id = name = submitSourceCouchAddr
	var bellCouchServerData = {sourceCouchAddr: $("#txtboxCouchServerSrc").val()};
	socket.emit('fetchDataFromIdentifiedBeLLCouchServer', bellCouchServerData);
}

$('#selectCouchSource').on('change', function() {
	var selectedOptionVal = $(this).val();
  $("#txtboxCouchServerSrc").val(selectedOptionVal);
});